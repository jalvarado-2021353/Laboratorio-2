
import { Schema, model } from 'mongoose';

const studentSchema = new Schema(
    {
        name: {
            type: String,
            required: [true, "Name is required"],
            trim: true
        },
        email: {
            type: String,
            required: [true, "Email is required"],
            unique: true,
            lowercase: true
        },
        password: {
            type: String,
            required: [true, "Password is required"]
        },
        role: {
            type: String,
            default: "STUDENT_ROLE",
            enum: ["STUDENT_ROLE"]
        },
        courses: {
            type: [Schema.Types.ObjectId],
            ref: "Course",
            default: []
        },
    },
    {
        versionKey: false,
        timestamps: true
    }
);

export default model('Student', studentSchema);