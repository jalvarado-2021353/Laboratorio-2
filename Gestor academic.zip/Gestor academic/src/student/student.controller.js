import Student from '../student/student.model.js';
import Course from '../course/course.model.js'
import bcrypt from 'bcryptjs'; 

export const registerStudent = async (req, res) => {
    try {
        const { name, password, email } = req.body;
        const existingStudent = await Student.findOne({ name })
        if (existingStudent) {
            return res.status(400).json({ message: 'Name already exists' });
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const newStudent = new Student({
            name,
            password: hashedPassword,
            email,
            role: 'STUDENT_ROLE'
        })
        await newStudent.save()
        res.status(201).json({
            message: 'Student registered successfully',
            student: {
                name: newStudent.name,
                email: newStudent.email,
                role: newStudent.role
            }
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'Error registering student' })
    }
}


export const loginStudent = async (req, res) => {
    try {
        const { name, password } = req.body;
        const student = await Student.findOne({ name });
        if (!student) {
            return res.status(404).json({ message: 'Student not found' })
        }
        const isPasswordValid = await bcrypt.compare(password, student.password)
        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Invalid password' })
        }
        res.status(200).json({
            message: 'Login successful',
            student: {
                name: student.name,
                email: student.email,
                role: student.role
            }
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'Error logging in' });
    }
}


export const assignCourse = async (req, res) => {
    try {
        const studentId = req.params.studentId;
        const { courseId } = req.body;
        const student = await Student.findById(studentId)
        if (!student) {
            return res.status(404).json({ message: 'Student not found' });
        }
        if (student.courses.includes(courseId)) {
            return res.status(400).json({ message: 'Already assigned to this course' });
        }
        if (student.courses.length >= 3) {
            return res.status(400).json({ message: 'Cannot enroll in more than 3 courses' });
        }
        const course = await Course.findById(courseId);
        if (!course) {
            return res.status(404).json({ message: 'Course not found' })
        }
        student.courses.push(courseId);
        await student.save()
        res.status(200).json({
            message: 'Course assigned successfully',
            student
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'Error assigning course' })
    }
}


export const updateStudent = async (req, res) => {
    try {
        const { studentId } = req.params 
        const { name, email } = req.body 
        const student = await Student.findById(studentId)
        if (!student) {
            return res.status(404).json({ message: 'Student not found' })
        } 
        if (student.role !== 'STUDENT_ROLE') {
            return res.status(403).json({ message: 'You cannot change the role' })
        }
        if (email && email !== student.email) {
            const existingStudent = await Student.findOne({ email })
            if (existingStudent) {
                return res.status(400).json({ message: 'Email is already in use' })
            }
        }
        student.name = name || student.name
        student.email = email || student.email
        await student.save()
        res.status(200).json({
            message: 'Profile updated successfully',
            student: {
                name: student.name,
                email: student.email
            }
        })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'Error updating profile' })
    }
}

export const deleteStudent = async (req, res) => {
    try {
        const { studentId } = req.params 
        const student = await Student.findById(studentId)
        if (!student) {
            return res.status(404).json({ message: 'Student not found' })
        }  
        if (student.role !== 'STUDENT_ROLE') {
            return res.status(403).json({ message: 'You are not authorized to delete this profile' })
        }
        await Student.findByIdAndDelete(studentId)
        res.status(200).json({ message: 'Profile deleted successfully' })
    } catch (err) {
        console.error(err)
        res.status(500).json({ message: 'Error delete profile' })
    }
}