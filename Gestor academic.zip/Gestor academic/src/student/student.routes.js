// routes/studentRoutes.js
import express from 'express';
import { registerStudent, loginStudent, assignCourse, updateStudent, deleteStudent  } from '../student/student.controller.js';

const api = express.Router()

api.post('/register', registerStudent)

api.post('/login', loginStudent)

api.post('/:studentId/assign-course', assignCourse)

api.put('/profile/:studentId', updateStudent)

api.delete(
    '/delete/:studentId', deleteStudent)

export default api;