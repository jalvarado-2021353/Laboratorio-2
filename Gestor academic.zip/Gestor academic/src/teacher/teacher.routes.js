// routes/teacherRoutes.js
import express from 'express';
import { registerTeacher, loginTeacher, createCourse, editCourse, deleteCourse, getTeacherCourse } from '../teacher/teacher.controller.js';

const api = express.Router();


api.post('/register', registerTeacher)

api.post('/login', loginTeacher)

api.post('/:teacherId/course', createCourse);

api.put('/:teacherId/update/:courseId', editCourse);

api.delete('/:teacherId/delete/:courseId', deleteCourse);

api.get('/:teacherId/course', getTeacherCourse);

export default api;