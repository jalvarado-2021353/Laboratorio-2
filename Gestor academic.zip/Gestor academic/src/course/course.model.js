import { Schema, model } from 'mongoose';

const courseSchema = new Schema(
    {
        name: {
            type: String,
            required: [true, "Course name is required"],
            maxLength: [50, "Can't be overcome 50 characters"]
        },
        description: {
            type: String,
            required: [true, "Description is required"],
            maxLength: [100, "Can't be overcome 100 characters"]
        },
        teacher: {
            type: Schema.Types.ObjectId,
            ref: "User",
            required: [true, "Teacher is required"]
        },
        students: [
            {
                type: Schema.Types.ObjectId,
                ref: "User"
            }
        ]
    },
    {
        versionKey: false,
        timestamps: true 
    }
);

export default model('Course', courseSchema)